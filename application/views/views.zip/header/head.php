    <link href="https://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,700&amp;#x7c;Trirong:200,200i,300,300i,400,400i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900&amp;#x7c" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/lib/owl.carousel/owl.carousel.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/lib/remodal/remodal.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/lib/remodal/remodal-default-theme.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/theme.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/lib/plyr/plyr.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/lib/Gridder/jquery.gridder.min.css" rel="stylesheet">


<!-- alert -->


    <link href="<?php echo base_url(); ?>alert/default.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>alert/semantic.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>alert/alertify.min.css" rel="stylesheet">

