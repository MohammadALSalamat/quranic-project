<!-- Bootstrap core CSS -->
<link href="<?php echo base_url('assets/admin/bootstrap/dist/css/bootstrap.min.css') ?>" rel="stylesheet" media="all">

<!-- Font Awesome -->
<link href="<?php echo base_url('assets/admin/font-awesome/css/font-awesome.min.css') ?>" rel="stylesheet" media="all">

<!-- Custom CSS  -->
<link href="<?php echo base_url('assets/admin/css/style.css') ?>" rel="stylesheet">
<script src="<?php echo base_url('assets/js/face.js') ?>"></script>

<link href="<?php echo base_url('assets/admin/themify-icons/css/themify-icons.css') ?>" rel="stylesheet">
<link href="<?php echo base_url('assets/admin/flag-icon-css/css/flag-icon.min.css') ?>" rel="stylesheet">
<link href="<?php echo base_url('assets/admin/selectFX/css/cs-skin-elastic.css') ?>" rel="stylesheet">
<link href="<?php echo base_url('assets/admin/jqvmap/dist/jqvmap.min.css') ?>" rel="stylesheet">
<link href="<?php echo base_url('assets/admin/Quill/quill.snow.css') ?>" rel="stylesheet">
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

<!-- Custom JS  -->
<script src="<?php echo base_url('assets/admin/js/jsscript.js') ?>"></script>
<script src="<?php echo base_url('assets/admin/js/video_admin.js') ?>"></script>

<!------------- Delete Confirmation ---------------> 
<script type="text/javascript">
    function delete_confirmation() {
        return confirm('Do you really want to delete the data?');
    }
</script>    
<script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>


