<!------------- Ban Confirmation ---------------> 
<script type="text/javascript">
    function are_you_sure() {
        return confirm('Are You Sure ?');
    }
</script>    